# Classic Arcade Game Clone Project

The idea is to recreate a simple clone of the classic Frogger arcade game.

## Table of Contents

- [Instructions](#instructions)
- [How to Play](#HowtoPlay)
- [Dependencies](#Dependencies)

# Instructions

In this game you have a Player and Enemies (Bugs). The goal of the player is to reach the water, without colliding into any one of the enemies. The player can move left, right, up and down. The enemies move in varying speeds on the paved block portion of the scene. Once the player reaches the water the game is won. Score 1 point for each successful crossing. Once a the player collides with an enemy, the game is reset and the player moves back to the start square. The bugs fight back and score points against you every time they run you over. They also get angrier and meaner the more wins you score.

# How to Play

Use the arrow keys to move your player across the play area.

# Dependencies for the Game
-index.html
-style.css
-app.js
-engine.js
-resources.js

## Contributing
